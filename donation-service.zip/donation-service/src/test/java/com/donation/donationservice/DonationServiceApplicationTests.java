package com.donation.donationservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DonationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
