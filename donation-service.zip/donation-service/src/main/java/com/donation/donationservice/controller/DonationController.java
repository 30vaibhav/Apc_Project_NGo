package com.donation.donationservice.controller;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.donation.donationservice.model.Donation;
import com.donation.donationservice.service.DonationService;

@CrossOrigin(origins="*")
@RestController
@RequestMapping("/donations")
public class DonationController {

    private final DonationService donationService;

    public DonationController(DonationService donationService) {
        this.donationService = donationService;
    }

    @GetMapping
    public List<Donation> getAllDonations() {
        return donationService.getAllDonations();
    }

    @PostMapping
    public Donation addDonation(@RequestBody Donation donation) {
        return donationService.addDonation(donation);
    }

    @GetMapping("/{id}")
    public Donation getDonationById(@PathVariable String id) {
        return donationService.getDonationById(id)
                .orElseThrow(() -> new RuntimeException("Donation not found with id " + id));
    }

    @GetMapping("/donor/{donorName}")
    public List<Donation> getDonationsByDonor(@PathVariable String donorName) {
        return donationService.getDonationsByDonor(donorName);
    }

    @GetMapping("/ngo/{ngoId}")
    public List<Donation> getDonationsByNgo(@PathVariable String ngoId) {
        return donationService.getDonationsByNgo(ngoId);
    }

    @PutMapping("/{id}")
    public Donation updateDonation(@PathVariable String id, @RequestBody Donation donation) {
        return donationService.updateDonation(id, donation);
    }

    @DeleteMapping("/{id}")
    public String deleteDonation(@PathVariable String id) {
        donationService.deleteDonation(id);
        return "Donation with id " + id + " deleted successfully!";
    }
}
