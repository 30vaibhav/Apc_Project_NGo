const ngoApi = "http://localhost:8080/ngos";
const donationApi = "http://localhost:8082/donations";

function showSection(sectionId) {
  document.getElementById("ngo-section").classList.add("hidden");
  document.getElementById("donation-section").classList.add("hidden");
  document.getElementById(sectionId).classList.remove("hidden");
}

// NGOs
const ngoForm = document.getElementById("ngoForm");
ngoForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const ngo = {
    name: document.getElementById("ngoName").value,
    registrationNumber: document.getElementById("ngoRegNo").value,
    cause: document.getElementById("ngoCause").value
  };
  await fetch(ngoApi, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(ngo)
  });
  ngoForm.reset();
  loadNgos();
});

async function loadNgos() {
  const res = await fetch(ngoApi);
  const ngos = await res.json();
  const table = document.getElementById("ngoTable");
  table.innerHTML = "";
  ngos.forEach(n => {
    table.innerHTML += `
      <tr>
        <td>${n.id}</td>
        <td>${n.name}</td>
        <td>${n.registrationNumber}</td>
        <td>${n.cause}</td>
        <td>
          <button class="btn-small btn-edit" onclick="editNgo('${n.id}')">Edit</button>
          <button class="btn-small btn-delete" onclick="deleteNgo('${n.id}')">Delete</button>
        </td>
      </tr>`;
  });
}

async function deleteNgo(id) {
  await fetch(`${ngoApi}/${id}`, { method: "DELETE" });
  loadNgos();
}

function editNgo(id) {
  const newName = prompt("Enter new NGO name:");
  if (newName) {
    fetch(`${ngoApi}/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: newName, registrationNumber: "Updated", cause: "Updated" })
    }).then(loadNgos);
  }
}

// Donations
const donationForm = document.getElementById("donationForm");
donationForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const donation = {
    donorName: document.getElementById("donorName").value,
    amount: parseFloat(document.getElementById("amount").value),
    ngoId: document.getElementById("ngoId").value
  };
  await fetch(donationApi, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(donation)
  });
  donationForm.reset();
  loadDonations();
});

async function loadDonations() {
  const res = await fetch(donationApi);
  const donations = await res.json();
  const table = document.getElementById("donationTable");
  table.innerHTML = "";
  donations.forEach(d => {
    table.innerHTML += `
      <tr>
        <td>${d.id}</td>
        <td>${d.donorName}</td>
        <td>${d.amount}</td>
        <td>${d.ngoId}</td>
        <td>${d.donationDate}</td>
        <td>
          <button class="btn-small btn-edit" onclick="editDonation('${d.id}')">Edit</button>
          <button class="btn-small btn-delete" onclick="deleteDonation('${d.id}')">Delete</button>
        </td>
      </tr>`;
  });
}

async function deleteDonation(id) {
  await fetch(`${donationApi}/${id}`, { method: "DELETE" });
  loadDonations();
}

function editDonation(id) {
  const newName = prompt("Enter new donor name:");
  if (newName) {
    fetch(`${donationApi}/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ donorName: newName, amount: 999, ngoId: "Updated" })
    }).then(loadDonations);
  }
}

// Initial load
loadNgos();
loadDonations();
